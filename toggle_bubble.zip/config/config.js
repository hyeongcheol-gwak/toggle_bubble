module.exports = {
  CLIENT_ID:
    "9447466321-9mm8v9p1ohln9dqjoeql8p7q6iemjvo0.apps.googleusercontent.com",
  CLIENT_SECRET: "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",
  REDIRECT_URI: "https://togglecampus.bubbleapps.io/version-test/toggle",
  OPENAI_API_KEY: "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",
  MYSQLHOST: "togglecampus.c6zeghi2rvqi.us-east-1.rds.amazonaws.com",
  MYSQLUSER: "toggle",
  MYSQLPASSWORD: "toggle1234!",
  MYSQLDATABASE: "togglecampus",
};
